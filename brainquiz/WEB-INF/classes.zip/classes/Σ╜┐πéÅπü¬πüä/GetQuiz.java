import java.util.ArrayList;
public class GetQuiz extends Object
{
   private  String question;
   private  ArrayList<String>choices;

}